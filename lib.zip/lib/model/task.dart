class Task {
  Task({required this.title, required this.description});
  final String title;
  final String description;
}
